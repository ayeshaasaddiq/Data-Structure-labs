#include <iostream>
using namespace std;

struct Inventory
{
    int serialNum;
    int year;
    int lotNum;
    Inventory* next;
};

Inventory* top = NULL;

void push(int s, int y, int l)
{
    Inventory* temp = new Inventory();

    temp->serialNum = s;
    temp->year = y;
    temp->lotNum = l;

    temp->next = top;
    top = temp;
}

void pop()
{
    if(top == NULL)
    {
        cout<<"Stack Empty"<<endl;
        return;
    }

    cout<<"Removed Part Serial: "<<top->serialNum<<endl;

    Inventory* temp = top;
    top = top->next;
    delete temp;
}

void display()
{
    Inventory* temp = top;

    cout<<"\nRemaining Parts\n";

    while(temp != NULL)
    {
        cout<<"Serial: "<<temp->serialNum<<endl;
        cout<<"Year: "<<temp->year<<endl;
        cout<<"Lot: "<<temp->lotNum<<endl;
        cout<<"----------"<<endl;

        temp = temp->next;
    }
}

int main()
{
    int choice, s, y, l;

    do
    {
        cout<<"\n1 Add Part";
        cout<<"\n2 Remove Part";
        cout<<"\n3 Display";
        cout<<"\n4 Exit\n";

        cin>>choice;

        if(choice == 1)
        {
            cout<<"Enter Serial Number: ";
            cin>>s;

            cout<<"Enter Year: ";
            cin>>y;

            cout<<"Enter Lot Number: ";
            cin>>l;

            push(s,y,l);
        }

        else if(choice == 2)
        {
            pop();
        }

        else if(choice == 3)
        {
            display();
        }

    }
    while(choice != 4);

    return 0;
}

#include <iostream>
using namespace std;

struct Node
{
    string title;
    int price;
    int edition;
    int pages;
    Node* next;
};

Node* top = NULL;


void push(string t,int p,int e,int pg)
{
    Node* temp = new Node();

    temp->title = t;
    temp->price = p;
    temp->edition = e;
    temp->pages = pg;

    temp->next = top;
    top = temp;
}

void pop()
{
    if(top==NULL)
    {
        cout<<"Stack empty"<<endl;
        return;
    }

    cout<<"Removed book: "<<top->title<<endl;

    Node* temp = top;
    top = top->next;
    delete temp;
}
void peek()
{
    if(top==NULL)
    {
        cout<<"Stack empty"<<endl;
        return;
    }

    cout<<"Top Book: "<<top->title<<endl;
}


void display()
{
    Node* temp = top;

    while(temp!=NULL)
    {
        cout<<temp->title<<" ";
        cout<<temp->price<<" ";
        cout<<temp->edition<<" ";
        cout<<temp->pages<<endl;

        temp = temp->next;
    }
}

int main()
{
    push("Pre Calculus",100,3,400);
    push("Expository",200,2,350);
    push("OOP",300,1,300);
    push("Islamiat",400,2,420);
    push("English",500,3,500);

    peek();

    pop();
    pop();

    cout<<"Remaining Books:"<<endl;
    display();

    return 0;
}

#include <iostream>
using namespace std;

int main() {
    int arr[5] = {10, 20, 30, 40, 50};
    int *ptr = arr;   // pointer to array

    cout << "Array elements are:\n";
    for (int i = 0; i < 5; i++) {
        cout << *ptr << " ";
        ptr++;        // move to next element
    }

    return 0;
}

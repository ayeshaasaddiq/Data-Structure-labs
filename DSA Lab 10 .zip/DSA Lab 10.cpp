#include <iostream>
using namespace std;

#define SIZE 5

class Queue {
private:
    int arr[SIZE];
    int front, rear;

public:
   
    Queue() {
        front = -1;
        rear = -1;
        for (int i = 0; i < SIZE; i++)
            arr[i] = -1;  
    }

    
    void display(string operation) {
        cout << "\nAfter " << operation << ":\n";

        if (front == -1 || front > rear) {
            cout << "Queue is Empty\n";
        } else {
            cout << "Front value: " << arr[front] << endl;
            cout << "Rear value: " << arr[rear] << endl;
        }

        cout << "Array: ";
        for (int i = 0; i < SIZE; i++) {
            if (arr[i] == -1)
                cout << "_ ";
            else
                cout << arr[i] << " ";
        }
        cout << endl;
    }


    void enQueue(int value) {
        if (rear == SIZE - 1) {
            cout << "\nCannot enqueue " << value << " -> Queue Overflow!\n";
            display("enQueue(" + to_string(value) + ")");
            return;
        }

        if (front == -1)
            front = 0;

        arr[++rear] = value;
        display("enQueue(" + to_string(value) + ")");
    }

    
    void deQueue() {
        if (front == -1 || front > rear) {
            cout << "\nCannot dequeue -> Queue Underflow!\n";
            display("deQueue()");
            return;
        }

        cout << "\nDequeued element: " << arr[front] << endl;
        arr[front] = -1; 
        front++;

        
        if (front > rear) {
            front = rear = -1;
        }

        display("deQueue()");
    }
};

int main() {
    Queue q;

   
    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    q.deQueue();
    q.enQueue(40);
    q.enQueue(50);
    q.enQueue(60);  

    return 0;
}
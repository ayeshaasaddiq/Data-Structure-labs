#include <iostream>
using namespace std;

// Structure for User Profile
struct User {
    string username;
    int age;
    string email;
    User* next;
};

User* head = NULL;

// Create profile
void createProfile(string name, int age, string email) {
    User* newUser = new User();
    newUser->username = name;
    newUser->age = age;
    newUser->email = email;
    newUser->next = head;
    head = newUser;
}

// Update profile
void updateProfile(string name) {
    User* temp = head;
    while (temp != NULL) {
        if (temp->username == name) {
            cout << "Enter new age: ";
            cin >> temp->age;
            cout << "Enter new email: ";
            cin >> temp->email;
            cout << "Profile updated\n";
            return;
        }
        temp = temp->next;
    }
    cout << "Profile not found\n";
}

// Delete profile
void deleteProfile(string name) {
    if (head == NULL) {
        cout << "No profiles available\n";
        return;
    }

    if (head->username == name) {
        User* temp = head;
        head = head->next;
        delete temp;
        cout << "Profile deleted\n";
        return;
    }

    User* temp = head;
    while (temp->next != NULL && temp->next->username != name)
        temp = temp->next;

    if (temp->next == NULL) {
        cout << "Profile not found\n";
        return;
    }

    User* del = temp->next;
    temp->next = del->next;
    delete del;
    cout << "Profile deleted\n";
}

// Search profile
void searchProfile(string name) {
    User* temp = head;
    while (temp != NULL) {
        if (temp->username == name) {
            cout << "Username: " << temp->username
                 << ", Age: " << temp->age
                 << ", Email: " << temp->email << endl;
            return;
        }
        temp = temp->next;
    }
    cout << "Profile not found\n";
}

// Display all profiles
void displayProfiles() {
    if (head == NULL) {
        cout << "No profiles available\n";
        return;
    }

    User* temp = head;
    while (temp != NULL) {
        cout << "Username: " << temp->username
             << ", Age: " << temp->age
             << ", Email: " << temp->email << endl;
        temp = temp->next;
    }
}

int main() {
    createProfile("Ali", 20, "ali@gmail.com");
    createProfile("Sara", 22, "sara@gmail.com");
    createProfile("Ahmed", 21, "ahmed@gmail.com");

    cout << "\nAll Profiles:\n";
    displayProfiles();

    cout << "\nSearch Profile:\n";
    searchProfile("Sara");

    cout << "\nUpdate Profile:\n";
    updateProfile("Ali");

    cout << "\nDelete Profile:\n";
    deleteProfile("Ahmed");

    cout << "\nFinal Profiles:\n";
    displayProfiles();

    return 0;
}

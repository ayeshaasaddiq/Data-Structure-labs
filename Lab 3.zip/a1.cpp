#include <iostream>
using namespace std;

// Structure for Mobile Node
struct Mobile {
    string brand;
    int units;
    float price;
    Mobile* next;
};

Mobile* head = NULL;

// Add new mobile at end
void addMobile(string brand, int units, float price) {
    Mobile* newMobile = new Mobile();
    newMobile->brand = brand;
    newMobile->units = units;
    newMobile->price = price;
    newMobile->next = NULL;

    if (head == NULL) {
        head = newMobile;
        return;
    }

    Mobile* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newMobile;
}

// Delete mobile by brand name
void deleteMobile(string brand) {
    if (head == NULL) {
        cout << "Inventory is empty\n";
        return;
    }

    if (head->brand == brand) {
        Mobile* temp = head;
        head = head->next;
        delete temp;
        cout << "Mobile deleted\n";
        return;
    }

    Mobile* temp = head;
    while (temp->next != NULL && temp->next->brand != brand)
        temp = temp->next;

    if (temp->next == NULL) {
        cout << "Mobile not found\n";
        return;
    }

    Mobile* del = temp->next;
    temp->next = del->next;
    delete del;
    cout << "Mobile deleted\n";
}

// Display all mobiles
void displayMobiles() {
    if (head == NULL) {
        cout << "No mobiles available\n";
        return;
    }

    Mobile* temp = head;
    while (temp != NULL) {
        cout << "Brand: " << temp->brand
             << ", Units: " << temp->units
             << ", Price: " << temp->price << endl;
        temp = temp->next;
    }
}

int main() {
    addMobile("Samsung", 10, 85000);
    addMobile("Apple", 5, 150000);
    addMobile("Oppo", 20, 45000);

    cout << "\nMobile Inventory:\n";
    displayMobiles();

    deleteMobile("Apple");

    cout << "\nAfter Deletion:\n";
    displayMobiles();

    return 0;
}

#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string name;
    int score;
    Node* next;
    Node* prev;

    Node(string n, int s) {
        name = n;
        score = s;
        next = NULL;
        prev = NULL;
    }
};

class DoublyLinkedList {
private:
    Node* head;

public:
    DoublyLinkedList() {
        head = NULL;
    }

    // Insert in sorted order (ascending by score)
    void addPlayer(string name, int score) {
        Node* newNode = new Node(name, score);

        if (head == NULL) {
            head = newNode;
            return;
        }

        Node* temp = head;

        // Insert at beginning
        if (score < head->score) {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
            return;
        }

        // Find correct position
        while (temp->next != NULL && temp->next->score <= score) {
            temp = temp->next;
        }

        newNode->next = temp->next;
        newNode->prev = temp;

        if (temp->next != NULL) {
            temp->next->prev = newNode;
        }

        temp->next = newNode;
    }

    // Delete by name
    void deletePlayer(string name) {
        Node* temp = head;

        while (temp != NULL && temp->name != name) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "Player not found.\n";
            return;
        }

        if (temp == head) {
            head = temp->next;
            if (head != NULL)
                head->prev = NULL;
        } else {
            temp->prev->next = temp->next;
            if (temp->next != NULL)
                temp->next->prev = temp->prev;
        }

        delete temp;
        cout << "Player deleted successfully.\n";
    }

    // Display whole list
    void display() {
        Node* temp = head;
        cout << "\nPlayers List (Ascending Order):\n";
        while (temp != NULL) {
            cout << temp->name << " - Score: " << temp->score << endl;
            temp = temp->next;
        }
    }

    // Display lowest score
    void displayLowest() {
        if (head == NULL) {
            cout << "List is empty.\n";
            return;
        }

        cout << "Lowest Score Player:\n";
        cout << head->name << " - Score: " << head->score << endl;
    }

    // Display players with same score
    void displaySameScore(int score) {
        Node* temp = head;
        bool found = false;

        while (temp != NULL) {
            if (temp->score == score) {
                cout << temp->name << " - Score: " << temp->score << endl;
                found = true;
            }
            temp = temp->next;
        }

        if (!found) {
            cout << "No players found with this score.\n";
        }
    }

    // Display backward from a player
    void displayBackwardFrom(string name) {
        Node* temp = head;

        while (temp != NULL && temp->name != name) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "Player not found.\n";
            return;
        }

        cout << "Players behind " << name << ":\n";
        temp = temp->prev;

        while (temp != NULL) {
            cout << temp->name << " - Score: " << temp->score << endl;
            temp = temp->prev;
        }
    }
};

int main() {
    DoublyLinkedList list;
    int choice, score;
    string name;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Lowest Score Player\n";
        cout << "5. Display Players with Same Score\n";
        cout << "6. Display Backward From Player\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter Player Name: ";
            cin >> name;
            cout << "Enter Score: ";
            cin >> score;
            list.addPlayer(name, score);
            break;

        case 2:
            cout << "Enter Player Name to delete: ";
            cin >> name;
            list.deletePlayer(name);
            break;

        case 3:
            list.display();
            break;

        case 4:
            list.displayLowest();
            break;

        case 5:
            cout << "Enter score to search: ";
            cin >> score;
            list.displaySameScore(score);
            break;

        case 6:
            cout << "Enter Player Name: ";
            cin >> name;
            list.displayBackwardFrom(name);
            break;

        case 0:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice.\n";
        }

    } while (choice != 0);

    return 0;
}

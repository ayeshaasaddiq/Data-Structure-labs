#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int val) {
        data = val;
        prev = NULL;
        next = NULL;
    }
};

class DoublyLinkedList {
private:
    Node* head;

public:
    DoublyLinkedList() {
        head = NULL;
    }

    // a) Create list from user input
    void createList(int n) {
        int value;
        for (int i = 0; i < n; i++) {
            cout << "Enter mark: ";
            cin >> value;

            Node* newNode = new Node(value);

            if (head == NULL) {
                head = newNode;
            } else {
                Node* temp = head;
                while (temp->next != NULL) {
                    temp = temp->next;
                }
                temp->next = newNode;
                newNode->prev = temp;
            }
        }
    }

    // b) Insert at beginning
    void addAtBeginning(int value) {
        Node* newNode = new Node(value);

        if (head != NULL) {
            newNode->next = head;
            head->prev = newNode;
        }

        head = newNode;
    }

    // c) Insert after value 45
    void addAfter45(int value) {
        Node* temp = head;

        while (temp != NULL && temp->data != 45) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "45 not found in list.\n";
            return;
        }

        Node* newNode = new Node(value);

        newNode->next = temp->next;
        newNode->prev = temp;

        if (temp->next != NULL) {
            temp->next->prev = newNode;
        }

        temp->next = newNode;
    }

    // d) Delete at beginning
    void deleteAtBeginning() {
        if (head == NULL) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        head = head->next;

        if (head != NULL) {
            head->prev = NULL;
        }

        delete temp;
    }

    // e) Delete after value 45
    void deleteAfter45() {
        Node* temp = head;

        while (temp != NULL && temp->data != 45) {
            temp = temp->next;
        }

        if (temp == NULL || temp->next == NULL) {
            cout << "No node exists after 45.\n";
            return;
        }

        Node* delNode = temp->next;

        temp->next = delNode->next;

        if (delNode->next != NULL) {
            delNode->next->prev = temp;
        }

        delete delNode;
    }

    // Display list
    void display() {
        Node* temp = head;
        cout << "Doubly Linked List: ";
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    DoublyLinkedList list;
    int n, value;

    cout << "Enter number of students: ";
    cin >> n;

    list.createList(n);
    list.display();

    // Insert at beginning
    cout << "Enter value to insert at beginning: ";
    cin >> value;
    list.addAtBeginning(value);
    list.display();

    // Insert after 45
    cout << "Enter value to insert after 45: ";
    cin >> value;
    list.addAfter45(value);
    list.display();

    // Delete at beginning
    list.deleteAtBeginning();
    cout << "After deleting at beginning:\n";
    list.display();

    // Delete after 45
    list.deleteAfter45();
    cout << "After deleting node after 45:\n";
    list.display();

    return 0;
}

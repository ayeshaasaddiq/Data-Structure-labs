#include <iostream>
using namespace std;

class Node {
public:
    double data;
    Node* prev;
    Node* next;

    Node(double val) {
        data = val;
        prev = NULL;
        next = NULL;
    }
};

class DoublyLinkedList {
private:
    Node* head;

public:
    DoublyLinkedList() {
        head = NULL;
    }

    // Insert at end
    void insert(double value) {
        Node* newNode = new Node(value);

        if (head == NULL) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }

    // Calculate and display results
    void calculateRainfall() {
        if (head == NULL) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        double total = 0;
        double highest = head->data;
        double lowest = head->data;
        int day = 1, highDay = 1, lowDay = 1;

        while (temp != NULL) {
            total += temp->data;

            if (temp->data > highest) {
                highest = temp->data;
                highDay = day;
            }

            if (temp->data < lowest) {
                lowest = temp->data;
                lowDay = day;
            }

            temp = temp->next;
            day++;
        }

        double average = total / 7;

        cout << "\nTotal Rainfall: " << total << endl;
        cout << "Average Rainfall: " << average << endl;
        cout << "Highest Rainfall: " << highest << " on Day " << highDay << endl;
        cout << "Lowest Rainfall: " << lowest << " on Day " << lowDay << endl;
    }

    // Rainfall after 5th node
    void rainfallAfter5th() {
        Node* temp = head;
        int count = 1;

        while (temp != NULL && count < 6) {
            temp = temp->next;
            count++;
        }

        if (temp != NULL) {
            cout << "Rainfall after 5th day (Day 6): " << temp->data << endl;
        } else {
            cout << "No node exists after 5th day.\n";
        }
    }
};

int main() {
    DoublyLinkedList list;
    double rainfall;

    cout << "Enter rainfall for 7 days:\n";

    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Day " << i << ": ";
            cin >> rainfall;

            if (rainfall < 0) {
                cout << "Invalid input! Rainfall cannot be negative. Try again.\n";
            }

        } while (rainfall < 0);

        list.insert(rainfall);
    }

    list.calculateRainfall();
    list.rainfallAfter5th();

    return 0;
}

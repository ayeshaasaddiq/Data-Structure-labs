#include <iostream>
using namespace std;

#define SIZE 5

int queueArr[SIZE];
int front = -1, rear = -1;

void enqueue(int value) {
    if (rear == SIZE - 1) {
        cout << "Overflow\n";
    } else {
        if (front == -1) front = 0;
        queueArr[++rear] = value;
    }
}

int countElements() {
    if (front == -1 || front > rear)
        return 0;
    return rear - front + 1;
}

int main() {
    enqueue(1);
    enqueue(2);
    enqueue(3);

    cout << "Number of elements: " << countElements() << endl;

    return 0;
}

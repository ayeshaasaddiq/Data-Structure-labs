#include <iostream>
using namespace std;

struct Node {
    string name;
    Node* next;
};

Node* last = NULL;


void add(string name) {
    Node* temp = new Node();
    temp->name = name;

    if (last == NULL) {
        last = temp;
        temp->next = temp;
    } else {
        temp->next = last->next;
        last->next = temp;
        last = temp;
    }
    cout << "Added successfully\n";
}


void search(string name) {
    if (last == NULL) return;

    Node* temp = last->next;
    do {
        if (temp->name == name) {
            cout << "Found\n";
            return;
        }
        temp = temp->next;
    } while (temp != last->next);

    cout << "Not found\n";
}


void del(string name) {
    if (last == NULL) return;

    Node *curr = last->next, *prev = last;

    do {
        if (curr->name == name) {

            if (curr == last && curr->next == last)
                last = NULL;
            else if (curr == last)
                last = prev;

            prev->next = curr->next;
            delete curr;

            cout << "Deleted successfully\n";
            return;
        }

        prev = curr;
        curr = curr->next;

    } while (curr != last->next);

    cout << "Not found\n";
}


void display() {
    if (last == NULL) return;

    Node* temp = last->next;
    do {
        cout << temp->name << " ";
        temp = temp->next;
    } while (temp != last->next);

    cout << endl;
}

int main() {
    add("Malik");
    add("Ayesha");
    add("Tayyab");

    display();

    search("Tayyab");

    del("Malik");
    display();

    return 0;
}

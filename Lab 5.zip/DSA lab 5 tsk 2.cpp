#include<iostream>
using namespace std;

struct Node
{
    int rain;
    Node* prev;
    Node* next;
};

Node* head=NULL;

void insert(int value)
{
    Node* newNode=new Node();
    newNode->rain=value;
    newNode->next=NULL;
    newNode->prev=NULL;

    if(head==NULL)
    {
        head=newNode;
        return;
    }

    Node* temp=head;

    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newNode;
    newNode->prev=temp;
}

int main()
{
    int rain,total=0;
    int highest=-1,lowest=9999;

    cout<<"Enter rainfall for 7 days\n";

    for(int i=1;i<=7;i++)
    {
        cout<<"Day "<<i<<": ";
        cin>>rain;

        if(rain<0)
        {
            cout<<"Negative values not allowed\n";
            i--;
            continue;
        }

        insert(rain);

        total+=rain;

        if(rain>highest)
            highest=rain;

        if(rain<lowest)
            lowest=rain;
    }

    cout<<"Total Rainfall = "<<total<<endl;
    cout<<"Average Rainfall = "<<total/7.0<<endl;
    cout<<"Highest Rainfall = "<<highest<<endl;
    cout<<"Lowest Rainfall = "<<lowest<<endl;

    Node* temp=head;

    for(int i=1;i<6;i++)
        temp=temp->next;

    cout<<"Rainfall after 5th node = "<<temp->rain<<endl;

    return 0;
}